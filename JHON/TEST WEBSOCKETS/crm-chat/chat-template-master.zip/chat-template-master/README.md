# Chat template v1.0.0

Log - v1.0.0
===================
Chat template for Web Application

### Tech used:
- HTML5
- CSS Grid
- Bootstrap v3.3 (used for Glyphicons only)

### Preview
![alt text](https://i.imgur.com/bI7Oy6z.png)
